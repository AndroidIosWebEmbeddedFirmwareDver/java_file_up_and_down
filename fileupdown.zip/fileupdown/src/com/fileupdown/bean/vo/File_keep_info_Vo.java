package com.fileupdown.bean.vo;




public class File_keep_info_Vo{
	
	private Integer fki_nm_id;
	private String fki_tt_cd;
	private String fki_tt_md;
	private String fki_st_fn;
	private Integer fki_st_fz;
	private String fki_st_fp;
	private String fki_st_ft;
	private String fki_st_ip;
	public Integer getFki_nm_id() {
		return fki_nm_id;
	}
	public void setFki_nm_id(Integer fki_nm_id) {
		this.fki_nm_id = fki_nm_id;
	}
	public String getFki_tt_cd() {
		return fki_tt_cd;
	}
	public void setFki_tt_cd(String fki_tt_cd) {
		this.fki_tt_cd = fki_tt_cd;
	}
	public String getFki_tt_md() {
		return fki_tt_md;
	}
	public void setFki_tt_md(String fki_tt_md) {
		this.fki_tt_md = fki_tt_md;
	}
	public String getFki_st_fn() {
		return fki_st_fn;
	}
	public void setFki_st_fn(String fki_st_fn) {
		this.fki_st_fn = fki_st_fn;
	}
	public Integer getFki_st_fz() {
		return fki_st_fz;
	}
	public void setFki_st_fz(Integer fki_st_fz) {
		this.fki_st_fz = fki_st_fz;
	}
	public String getFki_st_fp() {
		return fki_st_fp;
	}
	public void setFki_st_fp(String fki_st_fp) {
		this.fki_st_fp = fki_st_fp;
	}
	public String getFki_st_ft() {
		return fki_st_ft;
	}
	public void setFki_st_ft(String fki_st_ft) {
		this.fki_st_ft = fki_st_ft;
	}
	public String getFki_st_ip() {
		return fki_st_ip;
	}
	public void setFki_st_ip(String fki_st_ip) {
		this.fki_st_ip = fki_st_ip;
	}
	
}
