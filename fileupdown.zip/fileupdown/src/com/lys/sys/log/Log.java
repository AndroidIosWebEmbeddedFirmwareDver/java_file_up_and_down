package com.lys.sys.log;
import org.apache.log4j.Logger;

public class Log {
	public static final Logger in = Logger.getLogger(Log.class);
}
