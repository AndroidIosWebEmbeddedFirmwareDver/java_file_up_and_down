package com.lys.power.biz;


/***
 * 缓存接口
 * @author lys
 *
 */
public interface PowerCacheBiz{ 
//	/**
//	 * 取得所有菜单
//	 * @return 菜单的map集合
//	 */
//	public Map<String, Object> get_power_allmenu();
//	/**
//	 * 删除菜单缓存
//	 * @return
//	 */
//	public boolean del_power_allmenu();
//	/**
//	 * 取得所有字典
//	 * @return 字典的map集合
//	 */
//	public Map<String,Map<String,Object>> get_power_allcode();
//	/**
//	 * 删除字典缓存
//	 * @return
//	 */
//	public boolean del_power_allcode();
}
